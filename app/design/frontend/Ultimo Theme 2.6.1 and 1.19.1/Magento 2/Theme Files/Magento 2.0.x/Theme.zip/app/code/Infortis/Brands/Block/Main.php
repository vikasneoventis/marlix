<?php
namespace Infortis\Brands\Block;
class Main extends \Magento\Framework\View\Element\Template
{
	// TODO: remove this class
}