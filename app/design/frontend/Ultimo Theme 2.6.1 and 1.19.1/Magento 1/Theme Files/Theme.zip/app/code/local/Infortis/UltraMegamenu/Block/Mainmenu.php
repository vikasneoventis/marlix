<?php
/**
 * Main menu bar in the site header
 *
 */

class Infortis_UltraMegamenu_Block_Mainmenu extends Mage_Core_Block_Template
{
}