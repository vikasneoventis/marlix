<?php

/**
 * Form textarea element
 */
class Infortis_UltraMegamenu_Block_Category_Attribute_Helper_Grid_Columns
	extends Infortis_Infortis_Lib_Data_Form_Element_Grid_Columns
{
	protected $_maxColumns = 3;
	protected $_gridUnitMax = 12;
	protected $_labels = array('Left Block', 'Subcategories', 'Right Block');
}